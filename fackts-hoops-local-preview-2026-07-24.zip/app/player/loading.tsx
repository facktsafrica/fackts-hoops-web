export default function PlayerPortalLoading() {
  return (
    <main className="min-h-screen bg-slate-950 px-4 py-6 text-white sm:px-6">
      <div className="mx-auto max-w-7xl animate-pulse">
        <div className="flex items-center gap-4">
          <div className="h-18 w-18 rounded-2xl bg-slate-800 sm:h-24 sm:w-24" />
          <div className="min-w-0 flex-1">
            <div className="h-3 w-28 rounded bg-slate-800" />
            <div className="mt-3 h-8 max-w-sm rounded-lg bg-slate-800" />
          </div>
        </div>
        <div className="mt-7 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-24 rounded-2xl border border-slate-800 bg-slate-900 md:h-40"
            />
          ))}
        </div>
      </div>
    </main>
  );
}
