export default function OneOnOneLoading() {
  return (
    <main className="min-h-screen bg-slate-950 px-4 py-6 text-white sm:px-6">
      <div className="mx-auto max-w-6xl animate-pulse">
        <div className="h-7 w-40 rounded-full bg-slate-800" />
        <div className="mt-4 h-10 w-64 rounded-xl bg-slate-800" />
        <div className="mt-7 grid grid-cols-4 divide-x divide-slate-800 overflow-hidden rounded-2xl border border-slate-800">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="h-16 bg-slate-900" />
          ))}
        </div>
        <div className="mt-8 space-y-3">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-28 rounded-2xl border border-slate-800 bg-slate-900"
            />
          ))}
        </div>
      </div>
    </main>
  );
}
