import Link from "next/link";
import { supabase } from "@/lib/supabase";

export const revalidate = 60;

type PlayerCard = {
  id: string;
  full_name?: string | null;
  name?: string | null;
  nickname?: string | null;
  jersey_number?: number | string | null;
  position?: string | null;
  role?: string | null;
  photo_url?: string | null;
  photo_position?: string | null;
  is_featured?: boolean | null;

  // Optional classification fields, in case they exist in Supabase.
  player_type?: string | null;
  roster_status?: string | null;
  category?: string | null;
  is_guest?: boolean | null;

  games_played: number;
  points_per_game: number;
  rebounds_per_game: number;
  assists_per_game: number;
  total_points: number;
};

type PlayerRecord = Omit<
  PlayerCard,
  | "games_played"
  | "points_per_game"
  | "rebounds_per_game"
  | "assists_per_game"
  | "total_points"
>;

type PlayerStatRecord = {
  player_id: string;
  points?: number | null;
  rebounds?: number | null;
  assists?: number | null;
};

function hasValue(value?: string | number | null) {
  if (value === null || value === undefined) return false;
  return String(value).trim() !== "";
}

function getPlayerName(player: PlayerCard) {
  return player.full_name || player.name || player.nickname || "Unnamed Player";
}

function getInitials(player: PlayerCard) {
  return getPlayerName(player)
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

function isOfficialRosterPlayer(player: PlayerRecord) {
  const combinedType = [
    player.player_type,
    player.roster_status,
    player.category,
    player.role,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  if (player.is_guest === true) return false;
  if (combinedType.includes("guest")) return false;
  if (combinedType.includes("prospect")) return false;
  if (combinedType.includes("external")) return false;
  if (combinedType.includes("partner team")) return false;

  return true;
}

async function getPlayersWithStats() {
  const [playersResult, statsResult] = await Promise.all([
    supabase
      .from("players")
      .select(
        "id, full_name, name, nickname, jersey_number, position, role, photo_url, photo_position, is_featured, player_type, roster_status, category, is_guest"
      )
      .eq("is_active", true)
      .order("jersey_number", { ascending: true }),

    supabase
      .from("player_game_stats")
      .select("player_id, points, rebounds, assists"),
  ]);

  if (playersResult.error || statsResult.error) {
    return [];
  }

  const players = ((playersResult.data ?? []) as PlayerRecord[]).filter(
    isOfficialRosterPlayer
  );
  const stats = (statsResult.data ?? []) as PlayerStatRecord[];
  const statsByPlayer = new Map<string, PlayerStatRecord[]>();

  stats.forEach((row) => {
    const playerId = String(row.player_id ?? "");
    if (!playerId) return;

    const current = statsByPlayer.get(playerId) ?? [];
    current.push(row);
    statsByPlayer.set(playerId, current);
  });

  const rows: PlayerCard[] = players.map((player) => {
    const playerStats = statsByPlayer.get(String(player.id)) ?? [];
    const gamesPlayed = playerStats.length;

    const totals = playerStats.reduce(
      (acc, row) => {
        acc.points += Number(row.points ?? 0);
        acc.rebounds += Number(row.rebounds ?? 0);
        acc.assists += Number(row.assists ?? 0);
        return acc;
      },
      {
        points: 0,
        rebounds: 0,
        assists: 0,
      }
    );

    function avg(value: number) {
      return gamesPlayed > 0 ? Number((value / gamesPlayed).toFixed(1)) : 0;
    }

    return {
      id: player.id,
      full_name: player.full_name || player.name,
      name: player.name,
      nickname: player.nickname,
      jersey_number: player.jersey_number,
      position: player.position,
      role: player.role,
      photo_url: player.photo_url,
      photo_position: player.photo_position,
      is_featured: player.is_featured,
      player_type: player.player_type,
      roster_status: player.roster_status,
      category: player.category,
      is_guest: player.is_guest,
      games_played: gamesPlayed,
      points_per_game: avg(totals.points),
      rebounds_per_game: avg(totals.rebounds),
      assists_per_game: avg(totals.assists),
      total_points: totals.points,
    };
  });

  return rows;
}

export default async function PlayersPage() {
  const players = await getPlayersWithStats();

  const totalPlayers = players.length;
  const totalStatEntries = players.reduce(
    (acc, player) => acc + player.games_played,
    0
  );

  const topScorer = [...players].sort(
    (a, b) => b.points_per_game - a.points_per_game
  )[0];

  const mostExperienced = [...players].sort(
    (a, b) => b.games_played - a.games_played
  )[0];

  const featuredPlayers = players.filter((player) => player.is_featured);
  const regularPlayers = players.filter((player) => !player.is_featured);

  return (
    <main
      className="min-h-screen bg-black bg-cover bg-scroll bg-[position:left_top] px-0 text-white md:bg-fixed md:bg-[position:center_top]"
      style={{
        backgroundImage:
          "linear-gradient(rgba(2, 6, 23, 0.78), rgba(2, 6, 23, 0.94)), url('/images/one-on-one-bg.webp')",
      }}
    >
      <section className="relative overflow-hidden border-b border-white/10 bg-black/35 backdrop-blur-sm">
        <div className="absolute inset-0 opacity-20 [background-image:linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:42px_42px]" />

        <div className="relative mx-auto max-w-7xl px-5 py-9 sm:px-6 md:py-12 lg:px-8">
          <div className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-end">
            <div>
              <div className="mb-3 inline-flex rounded-full border border-orange-400/40 bg-orange-500/10 px-4 py-2 text-xs font-black uppercase tracking-[0.25em] text-orange-300">
                Official FACKTS Roster
              </div>

              <h1 className="text-4xl font-black uppercase tracking-tight sm:text-6xl">
                Players
              </h1>

              <p className="mt-4 max-w-3xl text-sm leading-7 text-zinc-300 sm:text-base">
                Official FACKTS Hoops players only. Guest hoopers, external
                ballers, and battle-only players live inside the Court Takeover
                portal.
              </p>

              <div className="mt-5 flex flex-wrap gap-3">
                <Link
                  href="/guest-hoopers"
                  className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-zinc-200 transition hover:border-orange-400 hover:text-orange-300"
                >
                  View Guest Hoopers
                </Link>

                <Link
                  href="/court-takeover"
                  className="rounded-full bg-orange-500 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-black transition hover:bg-orange-400"
                >
                  Court Takeover Portal
                </Link>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <HeroMiniStat label="Players" value={String(totalPlayers)} />
              <HeroMiniStat label="Games Logged" value={String(totalStatEntries)} />
              <HeroMiniStat
                label="Top PPG"
                value={topScorer ? String(topScorer.points_per_game) : "0"}
                sub={topScorer ? getPlayerName(topScorer) : "No data"}
              />
              <HeroMiniStat
                label="Most Games"
                value={
                  mostExperienced ? String(mostExperienced.games_played) : "0"
                }
                sub={mostExperienced ? getPlayerName(mostExperienced) : "No data"}
              />
            </div>
          </div>
        </div>
      </section>

      {featuredPlayers.length > 0 ? (
        <section className="mx-auto max-w-7xl px-5 py-8 sm:px-6 lg:px-8">
          <SectionHeader eyebrow="Spotlight" title="Featured Official Players" />

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {featuredPlayers.map((player) => (
              <PlayerCard key={player.id} player={player} featured />
            ))}
          </div>
        </section>
      ) : null}

      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-6 lg:px-8">
        <SectionHeader eyebrow="Roster" title="Official Active Players" />

        {players.length === 0 ? (
          <EmptyBox text="No official active players found yet." />
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            {(featuredPlayers.length > 0 ? regularPlayers : players).map((player) => (
              <PlayerCard key={player.id} player={player} />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

function PlayerCard({
  player,
  featured = false,
}: {
  player: PlayerCard;
  featured?: boolean;
}) {
  return (
    <Link
      href={`/players/${player.id}`}
      className="group grid min-h-[148px] grid-cols-[7.6rem_minmax(0,1fr)] overflow-hidden rounded-2xl border border-white/10 bg-zinc-950/95 shadow-lg shadow-black/20 transition duration-300 hover:-translate-y-1 hover:border-orange-400/60 hover:shadow-orange-950/30 md:block md:rounded-3xl"
    >
      <div className="relative min-h-[148px] overflow-hidden bg-black md:min-h-0">
        <div className="absolute left-3 top-3 z-10 flex flex-wrap gap-2">
          {hasValue(player.jersey_number) ? (
            <span className="rounded-full bg-orange-500 px-2.5 py-1 text-[10px] font-black text-black md:px-3 md:text-[11px]">
              #{player.jersey_number}
            </span>
          ) : null}

          <span className="hidden rounded-full border border-white/10 bg-black/70 px-3 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-white backdrop-blur sm:inline-flex">
            FACKTS Player
          </span>

          {featured ? (
            <span className="rounded-full border border-orange-400/40 bg-black/75 px-2.5 py-1 text-[9px] font-black uppercase tracking-[0.1em] text-orange-200 backdrop-blur md:px-3 md:text-[10px]">
              Featured
            </span>
          ) : null}
        </div>

        {player.photo_url ? (
          <img
            src={player.photo_url}
            alt={getPlayerName(player)}
            loading="lazy"
            decoding="async"
            className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105 md:static md:h-60"
            style={{
              objectPosition: player.photo_position || "center center",
            }}
          />
        ) : (
          <div className="flex h-full min-h-[148px] w-full items-center justify-center bg-[radial-gradient(circle,_rgba(249,115,22,0.25),_transparent_55%),#050505] md:h-60">
            <div className="text-center">
              <p className="text-3xl font-black text-orange-500 md:text-5xl">
                {getInitials(player) || "FH"}
              </p>
              <p className="mt-1 text-[8px] font-black uppercase tracking-[0.18em] text-zinc-600 md:text-[10px] md:tracking-[0.25em]">
                FACKTS Player
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="flex min-w-0 flex-col justify-between p-3 md:block md:p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="line-clamp-2 text-lg font-black leading-tight text-white group-hover:text-orange-200 md:line-clamp-1 md:text-xl">
              {getPlayerName(player)}
            </h2>

            {hasValue(player.nickname) ? (
              <p className="mt-1 line-clamp-1 text-xs font-bold text-orange-300 md:text-sm">
                “{player.nickname}”
              </p>
            ) : null}
          </div>

          {hasValue(player.position) ? (
            <span className="shrink-0 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[9px] font-black uppercase text-zinc-300 md:px-3 md:text-[10px]">
              {player.position}
            </span>
          ) : null}
        </div>

        {hasValue(player.role) ? (
          <div className="mt-2 md:mt-3">
            <span className="line-clamp-1 text-[9px] font-black uppercase tracking-[0.1em] text-orange-200 md:inline-flex md:rounded-full md:border md:border-orange-500/30 md:bg-orange-500/10 md:px-3 md:py-1 md:text-[10px] md:tracking-[0.12em]">
              {player.role}
            </span>
          </div>
        ) : null}

        <div className="mt-3 grid grid-cols-4 divide-x divide-white/10 overflow-hidden rounded-xl border border-white/10 bg-black/55 md:mt-4 md:gap-2 md:divide-x-0 md:overflow-visible md:border-0 md:bg-transparent">
          <StatPill label="GP" value={player.games_played} />
          <StatPill label="PPG" value={player.points_per_game} />
          <StatPill label="RPG" value={player.rebounds_per_game} />
          <StatPill label="APG" value={player.assists_per_game} />
        </div>

        <div className="mt-2 text-right md:mt-4">
          <span className="inline-flex items-center justify-end text-[10px] font-black uppercase tracking-[0.12em] text-orange-300 transition group-hover:text-orange-200 md:w-full md:justify-center md:rounded-full md:bg-orange-500 md:px-4 md:py-2 md:text-xs md:text-black md:group-hover:bg-orange-400">
            View profile <span className="ml-1" aria-hidden="true">→</span>
          </span>
        </div>
      </div>
    </Link>
  );
}

function HeroMiniStat({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/50 p-4 backdrop-blur-sm">
      <p className="text-[10px] font-black uppercase tracking-[0.18em] text-zinc-500">
        {label}
      </p>

      <p className="mt-2 text-3xl font-black text-white">{value}</p>

      {sub ? <p className="mt-1 truncate text-xs text-zinc-500">{sub}</p> : null}
    </div>
  );
}

function SectionHeader({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-5">
      <p className="text-xs font-black uppercase tracking-[0.25em] text-orange-300">
        {eyebrow}
      </p>

      <h2 className="mt-1 text-3xl font-black">{title}</h2>
    </div>
  );
}

function StatPill({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="px-1 py-1.5 text-center md:rounded-2xl md:border md:border-white/10 md:bg-black/60 md:px-2 md:py-3">
      <p className="text-[7px] font-black uppercase tracking-[0.08em] text-zinc-500 md:text-[9px] md:tracking-[0.12em]">
        {label}
      </p>

      <p className="mt-0.5 text-sm font-black text-white md:mt-1 md:text-base">{value}</p>
    </div>
  );
}

function EmptyBox({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-zinc-950/90 p-5 text-sm text-zinc-400 backdrop-blur-sm">
      {text}
    </div>
  );
}
