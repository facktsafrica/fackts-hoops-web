export default function PlayersLoading() {
  return (
    <main className="min-h-screen bg-slate-950 px-4 py-6 text-white sm:px-6">
      <div className="mx-auto max-w-7xl animate-pulse">
        <div className="h-7 w-32 rounded-full bg-slate-800" />
        <div className="mt-4 h-10 w-52 rounded-xl bg-slate-800" />
        <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, index) => (
            <div
              key={index}
              className="grid min-h-[148px] grid-cols-[7.6rem_minmax(0,1fr)] overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 md:block"
            >
              <div className="bg-slate-800 md:h-60" />
              <div className="space-y-3 p-4">
                <div className="h-5 w-3/4 rounded bg-slate-800" />
                <div className="h-3 w-1/2 rounded bg-slate-800" />
                <div className="h-9 rounded-xl bg-slate-800" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
