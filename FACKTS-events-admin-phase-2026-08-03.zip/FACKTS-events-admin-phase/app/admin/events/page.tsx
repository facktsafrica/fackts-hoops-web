"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";

type EventCase = { id: string; event_id: string; title: string; slug: string; summary: string | null; start_date: string | null; end_date: string | null; venue: string | null; location: string | null; status: string; photo_count: number; is_public: boolean };
type RecordRow = { id: string; event_id: string; record_type: string; title: string; subtitle: string | null; details: string | null; division: string | null; team_name: string | null; opponent_name: string | null; score_for: number | null; score_against: number | null; url: string | null; image_url: string | null; status: string; is_public: boolean };

const types = ["team", "person", "result", "partner", "media", "gallery", "award", "consent", "prize"] as const;
const privateTypes = new Set(["consent", "prize"]);
const emptyRecord = { record_type: "team", title: "", subtitle: "", details: "", division: "", team_name: "", opponent_name: "", score_for: "", score_against: "", url: "", image_url: "", status: "draft", is_public: false };

export default function AdminEventsPage() {
  const [events, setEvents] = useState<EventCase[]>([]);
  const [selected, setSelected] = useState("");
  const [records, setRecords] = useState<RecordRow[]>([]);
  const [tab, setTab] = useState<(typeof types)[number]>("team");
  const [form, setForm] = useState(emptyRecord);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState("Loading event workspace...");

  const loadEvents = useCallback(async () => {
    const { data, error } = await supabase.from("event_case_studies").select("*").order("created_at", { ascending: false });
    if (error) return setMessage(`Run the Events migration first: ${error.message}`);
    const rows = (data || []) as EventCase[];
    setEvents(rows); setSelected((current) => current || rows[0]?.event_id || ""); setMessage("");
  }, []);
  const loadRecords = useCallback(async () => {
    if (!selected) return;
    const { data, error } = await supabase.from("event_records").select("*").eq("event_id", selected).order("sort_order").order("created_at");
    if (error) return setMessage(error.message);
    setRecords((data || []) as RecordRow[]);
  }, [selected]);
  useEffect(() => { loadEvents(); }, [loadEvents]);
  useEffect(() => { loadRecords(); }, [loadRecords]);

  const active = events.find((event) => event.event_id === selected);
  const visible = useMemo(() => records.filter((row) => row.record_type === tab), [records, tab]);

  async function saveEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const data = new FormData(event.currentTarget);
    const payload = { title: String(data.get("title") || ""), summary: String(data.get("summary") || ""), venue: String(data.get("venue") || ""), location: String(data.get("location") || ""), start_date: String(data.get("start_date") || "") || null, end_date: String(data.get("end_date") || "") || null, photo_count: Number(data.get("photo_count") || 0), status: String(data.get("status") || "draft"), is_public: data.get("is_public") === "on", updated_at: new Date().toISOString() };
    const { error } = await supabase.from("event_case_studies").update(payload).eq("event_id", selected);
    setMessage(error ? error.message : "Event details saved."); if (!error) loadEvents();
  }

  async function saveRecord(event: FormEvent) {
    event.preventDefault(); if (!form.title.trim()) return setMessage("Add a name or title first.");
    const isPrivate = privateTypes.has(form.record_type);
    const payload = { ...form, event_id: selected, title: form.title.trim(), score_for: form.score_for === "" ? null : Number(form.score_for), score_against: form.score_against === "" ? null : Number(form.score_against), is_public: isPrivate ? false : form.is_public };
    const query = editingId ? supabase.from("event_records").update(payload).eq("id", editingId) : supabase.from("event_records").insert(payload);
    const { error } = await query; setMessage(error ? error.message : editingId ? "Record updated." : "Record added.");
    if (!error) { setEditingId(null); setForm({ ...emptyRecord, record_type: tab }); loadRecords(); }
  }

  function edit(row: RecordRow) { setEditingId(row.id); setTab(row.record_type as typeof tab); setForm({ record_type: row.record_type, title: row.title, subtitle: row.subtitle || "", details: row.details || "", division: row.division || "", team_name: row.team_name || "", opponent_name: row.opponent_name || "", score_for: row.score_for?.toString() || "", score_against: row.score_against?.toString() || "", url: row.url || "", image_url: row.image_url || "", status: row.status, is_public: row.is_public }); window.scrollTo({ top: 0, behavior: "smooth" }); }
  async function remove(id: string) { if (!window.confirm("Delete this record?")) return; const { error } = await supabase.from("event_records").delete().eq("id", id); setMessage(error ? error.message : "Record deleted."); if (!error) loadRecords(); }

  return <main className="min-h-screen bg-slate-950 px-4 py-8 text-white sm:px-6">
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[.22em] text-orange-300">Events control centre</p><h1 className="mt-2 text-3xl font-black uppercase sm:text-5xl">Event case studies</h1></div>{active ? <Link href={`/events/${active.slug}`} target="_blank" className="rounded-full border border-orange-400/50 px-5 py-3 text-xs font-black uppercase text-orange-200">Preview public page</Link> : null}</div>
      {message ? <p className="mt-5 rounded-2xl border border-blue-400/30 bg-blue-500/10 p-4 text-sm text-blue-100">{message}</p> : null}
      <div className="mt-6 grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
        <section className="rounded-3xl border border-white/10 bg-slate-900 p-5">
          <label className="text-xs font-black uppercase text-slate-400">Event</label><select value={selected} onChange={(e) => setSelected(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 font-bold">{events.map((item) => <option key={item.id} value={item.event_id}>{item.title}</option>)}</select>
          {active ? <form key={active.id} onSubmit={saveEvent} className="mt-5 grid gap-4"><Field name="title" label="Event title" value={active.title} /><TextArea name="summary" label="Public summary" value={active.summary || ""} /><div className="grid grid-cols-2 gap-3"><Field name="start_date" label="Start date" type="date" value={active.start_date || ""} /><Field name="end_date" label="End date" type="date" value={active.end_date || ""} /></div><div className="grid grid-cols-2 gap-3"><Field name="venue" label="Venue" value={active.venue || ""} /><Field name="location" label="Location" value={active.location || ""} /></div><Field name="photo_count" label="Photo archive count" type="number" value={String(active.photo_count || 0)} /><label className="text-xs font-black uppercase text-slate-400">Status<select name="status" defaultValue={active.status} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"><option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option></select></label><label className="flex items-center gap-3 text-sm font-bold"><input name="is_public" type="checkbox" defaultChecked={active.is_public} className="h-5 w-5" /> Show event publicly</label><button className="rounded-full bg-orange-500 px-5 py-3 text-xs font-black uppercase text-black">Save event details</button></form> : null}
        </section>
        <section className="rounded-3xl border border-white/10 bg-slate-900 p-5">
          <div className="flex gap-2 overflow-x-auto pb-3">{types.map((type) => <button key={type} onClick={() => { setTab(type); setEditingId(null); setForm({ ...emptyRecord, record_type: type }); }} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-black uppercase ${tab === type ? "bg-orange-500 text-black" : "bg-slate-800 text-slate-300"}`}>{type}s</button>)}</div>
          <p className="mt-2 text-xs text-slate-400">Consent and prize records are always private. Other records appear publicly only after you tick Public and set Published or Verified.</p>
          <form onSubmit={saveRecord} className="mt-5 grid gap-3 sm:grid-cols-2"><FieldControlled label="Name / title" value={form.title} set={(v) => setForm({ ...form, title: v })} /><FieldControlled label="Role / subtitle" value={form.subtitle} set={(v) => setForm({ ...form, subtitle: v })} /><FieldControlled label="Division" value={form.division} set={(v) => setForm({ ...form, division: v })} /><FieldControlled label="Team" value={form.team_name} set={(v) => setForm({ ...form, team_name: v })} />{tab === "result" ? <><FieldControlled label="Opponent" value={form.opponent_name} set={(v) => setForm({ ...form, opponent_name: v })} /><FieldControlled label="Score for" type="number" value={form.score_for} set={(v) => setForm({ ...form, score_for: v })} /><FieldControlled label="Score against" type="number" value={form.score_against} set={(v) => setForm({ ...form, score_against: v })} /></> : null}<FieldControlled label="Link URL" value={form.url} set={(v) => setForm({ ...form, url: v })} /><FieldControlled label="Image URL" value={form.image_url} set={(v) => setForm({ ...form, image_url: v })} /><label className="text-xs font-black uppercase text-slate-400">Status<select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-white"><option>draft</option><option>verified</option><option>published</option><option>hidden</option><option>restricted</option><option>withdrawn</option><option>pending</option><option>part-paid</option><option>settled</option></select></label><label className="sm:col-span-2 text-xs font-black uppercase text-slate-400">Notes<textarea value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} rows={3} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 normal-case text-white" /></label>{!privateTypes.has(tab) ? <label className="flex items-center gap-3 text-sm font-bold"><input type="checkbox" checked={form.is_public} onChange={(e) => setForm({ ...form, is_public: e.target.checked })} className="h-5 w-5" /> Public</label> : null}<button className="rounded-full bg-orange-500 px-5 py-3 text-xs font-black uppercase text-black">{editingId ? "Update record" : `Add ${tab}`}</button></form>
        </section>
      </div>
      <section className="mt-6 rounded-3xl border border-white/10 bg-slate-900 p-5"><h2 className="text-xl font-black uppercase">{tab}s ({visible.length})</h2><div className="mt-4 grid gap-3">{visible.map((row) => <article key={row.id} className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-slate-950 p-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap gap-2"><strong>{row.title}</strong><span className="rounded-full bg-slate-800 px-2 py-1 text-[10px] uppercase text-slate-300">{row.status}</span>{row.is_public ? <span className="rounded-full bg-emerald-500/20 px-2 py-1 text-[10px] uppercase text-emerald-200">Public</span> : null}</div><p className="mt-1 text-sm text-slate-400">{row.subtitle || row.details || "No extra details"}</p></div><div className="flex gap-2"><button onClick={() => edit(row)} className="rounded-full border border-blue-400/40 px-4 py-2 text-xs font-black text-blue-200">Edit</button><button onClick={() => remove(row.id)} className="rounded-full border border-red-400/40 px-4 py-2 text-xs font-black text-red-200">Delete</button></div></article>)}{!visible.length ? <p className="py-8 text-center text-sm text-slate-500">No {tab} records yet.</p> : null}</div></section>
    </div>
  </main>;
}

function Field({ name, label, value, type = "text" }: { name: string; label: string; value: string; type?: string }) { return <label className="text-xs font-black uppercase text-slate-400">{label}<input name={name} type={type} defaultValue={value} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 normal-case text-white" /></label>; }
function TextArea({ name, label, value }: { name: string; label: string; value: string }) { return <label className="text-xs font-black uppercase text-slate-400">{label}<textarea name={name} defaultValue={value} rows={4} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 normal-case text-white" /></label>; }
function FieldControlled({ label, value, set, type = "text" }: { label: string; value: string; set: (value: string) => void; type?: string }) { return <label className="text-xs font-black uppercase text-slate-400">{label}<input type={type} value={value} onChange={(e) => set(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 normal-case text-white" /></label>; }

