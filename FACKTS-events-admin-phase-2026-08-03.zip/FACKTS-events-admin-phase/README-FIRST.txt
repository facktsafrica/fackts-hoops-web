FACKTS EVENTS ADMIN — INSTALLATION

1. Copy the app and supabase folders into the main fackts-hoops-web project folder.
2. Choose Replace files when Windows asks.
3. In Supabase Dashboard, open SQL Editor.
4. Open supabase/migrations/20260803_event_case_studies.sql, copy all its contents, paste into SQL Editor, and click Run.
5. In PowerShell at the project root run:
   npm run build
6. If the build passes, run:
   npm run dev
7. Log into Admin and open Event Case Studies from the menu.

IMPORTANT
- Consent and prize records are private by database policy.
- Public records must be marked Public and have status Published or Verified.
- Do not run npm audit fix --force.
