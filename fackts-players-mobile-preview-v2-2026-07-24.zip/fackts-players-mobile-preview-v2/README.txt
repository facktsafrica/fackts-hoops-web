FACKTS PLAYERS MOBILE PREVIEW V2

This preview changes only:
app\players\page.tsx

Mobile improvements:
- Shorter 112px player rows
- Full player names can wrap instead of ending in ...
- Full position words are shown instead of being cut off
- GP, PPG, RPG and APG stay on one straight label row
- All four stat values stay on one straight number row
- The chevron was removed so player information gets the space

It does not change:
- desktop or laptop player-card design
- animations
- Supabase tables or migrations
- players, games, or one-on-one matches
- GitHub or the live site

APPLY
1. Extract this ZIP.
2. Open the extracted fackts-players-mobile-preview-v2 folder.
3. Double-click APPLY-PREVIEW.bat.

4. Return to your normal FACKTS project and run:

cd "C:\Users\user\Documents\APPS\FACKTS\hoops stat app\fackts-hoops-web"
npm run dev

5. Open http://localhost:3000/players
6. Use Chrome phone view to inspect the mobile rows.

RESTORE
If you do not like the preview, double-click RESTORE-ORIGINAL.bat.

Then restart npm run dev.
